#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

#define POT_PIN 34

float voltage = 230.0;
float current = 0;
float power = 0;
float energy = 0;

unsigned long previousTime = 0;

void setup() {
  Serial.begin(115200);

  analogReadResolution(12);

  Wire.begin(21, 19);

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Electricity");
  lcd.setCursor(0, 1);
  lcd.print("Consumption");
  delay(2000);
  lcd.clear();

  previousTime = millis();
}

void loop() {

  int potValue = analogRead(POT_PIN);

  // Current simulation: 0 to 10 Ampere
  current = (potValue / 4095.0) * 10.0;

  // Power calculation
  power = voltage * current;

  // Energy calculation in kWh
  unsigned long currentTime = millis();

  float hours =
    (currentTime - previousTime) / 3600000.0;

  energy += (power * hours) / 1000.0;

  previousTime = currentTime;

  // LCD Display
  lcd.setCursor(0, 0);
  lcd.print("V:");
  lcd.print(voltage, 0);
  lcd.print(" I:");
  lcd.print(current, 1);
  lcd.print("A ");

  lcd.setCursor(0, 1);
  lcd.print("P:");
  lcd.print(power, 0);
  lcd.print(" E:");
  lcd.print(energy, 3);
  lcd.print(" ");

  Serial.print("Pot Value: ");
  Serial.println(potValue);

  delay(300);
}